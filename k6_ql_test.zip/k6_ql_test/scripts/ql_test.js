import http from 'k6/http';
import { check } from 'k6';

const query_1 = open('/info/ql1.txt').trim();
const query_2 = open('/info/ql2.txt').trim();

const token = open('/info/token.txt').trim();

export let options = {
    vus: 10, 
    duration: '30s', 
};

const url = 'http://x5id-tdg2-test.x5.ru:8190/graphql';

const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
};

export default function () {

    // returns random integer between 0 and 2
    let request_index = Math.floor(Math.random() * 3);
    let res = null;
    if (request_index == 1) {
        res = http.post(
            url,
            JSON.stringify({ query: query_1 }),
            { headers: headers ,
              tags: {request_name: "GraphQL1"}
            }
        );
    }
    else if(request_index == 2){
        res = http.post(
            url,
            JSON.stringify({ query: query_2 }),
            { headers: headers ,
              tags: {request_name: "GraphQL2"}
            }
        );
    }

    check(res, {
        'status is 200': (r) => r.status === 200,
        'response is not empty': (r) => r.body && r.body.length > 0,
        'response contains valid JSON': (r) => {
            try {
                const json = JSON.parse(r.body);
                return json && typeof json === 'object';
            } catch (e) {
                return false;
            }
        },
        'response contains cursor': (r) => {
            try {
                const json = JSON.parse(r.body);
                // Assuming "data" and "sg_user_profile" are part of the GraphQL response structure
                return json?.data?.sg_user_profile?.cursor !== undefined;
            } catch (e) {
                return false;
            }
        },
    });
    
    res.tags.status = isSuccess ? 'success' : 'failure';
}

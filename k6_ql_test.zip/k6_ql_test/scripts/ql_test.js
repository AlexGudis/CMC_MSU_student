import http from 'k6/http';
import { check } from 'k6';
import { readFileSync } from 'fs';

// Чтение GraphQL запроса из файла
const query = readFileSync('../info/ql_exmp.txt', 'utf-8').trim();

// Чтение токена из файла
const token = readFileSync('../info/token.txt', 'utf-8').trim();

export let options = {
    vus: 10, // Количество виртуальных пользователей
    duration: '30s', // Длительность теста
};

const url = 'http://x5id-tdg2-test.x5.ru:8190/admin/tdg/repl'; // URL вашего Tarantool GraphQL

const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`, // Добавляем токен в заголовок
};

export default function () {
    const res = http.post(
        url,
        JSON.stringify({ query: query }),
        { headers: headers }
    );

    // Проверка ответа
    check(res, {
        'status is 200': (r) => r.status === 200,
        'response is not empty': (r) => r.body && r.body.length > 0,
    });
}

# Тестирование компонентов Тарантул


Текущие результаты: скрипт k6 обращается за данными в TDG через graphQL запрос

## Запуск тестирования
Последовательность команд для запуска и проверки:
```shell
docker compose up -d
docker exec -it k6 k6 run --out influxdb=http://influxdb:8086/metrics /scripts/ql_test.js
docker compose down -v
```